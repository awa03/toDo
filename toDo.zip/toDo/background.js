chrome.runtime.onInstalled.addListener(() => {
    // Service worker logic if needed upon installation.
});